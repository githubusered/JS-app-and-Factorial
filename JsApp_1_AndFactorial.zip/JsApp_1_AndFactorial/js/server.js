// //debugger
// 111111111111111111111111111111111111111111111111111111111111111111111111111111111111
// 1********************************************************************************

// const app = (event) => {
//     event = event || window.event;
//     event.preventDefault();
//     window.history.pushState({}, "", event.target.href);
//     handLocation();
// };

// const routes = {
//     404: "404.html",
//     "/n": "../index.html",
// };

// const handLocation = async () => {
//     const path = window.location.pathname;
//     const app = routes[path] || routes[404];
//     const html = await fetch(app).then((data) => data.text());
//     // document.getElementById("main-page").innerHTML node = html;
// };




// window.onpopstate = handLocation;
// window.app  = app;
// handLocation();

// ****************************************************************************
// 22222222222222222222222222222222222222222222222222222222222222222222222222222222
var http = require('http');
var app = require('../JsApp_1_AndFactorial/app');

http.createServer(app.handleRequest).listen(7000);

